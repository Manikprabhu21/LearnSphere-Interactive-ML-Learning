## Packages
react-markdown | Rendering markdown from AI responses
react-syntax-highlighter | Code highlighting for Code Mentor
@types/react-syntax-highlighter | TypeScript definitions
framer-motion | Page transitions and stunning animations
date-fns | Date formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
