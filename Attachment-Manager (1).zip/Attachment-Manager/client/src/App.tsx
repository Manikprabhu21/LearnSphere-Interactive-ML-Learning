import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Loader2 } from "lucide-react";
import NotFound from "@/pages/not-found";

import { useAuth } from "@/hooks/use-auth";
import { Shell } from "@/components/layout/shell";

// Pages
import Dashboard from "@/pages/dashboard";
import AiTutor from "@/pages/ai-tutor";
import CodeMentor from "@/pages/code-mentor";
import RoadmapsList from "@/pages/roadmaps/index";
import ViewRoadmap from "@/pages/roadmaps/view";
import ProjectsList from "@/pages/projects/index";
import ViewProject from "@/pages/projects/view";

// Loading Screen
function LoadingScreen() {
  return (
    <div className="flex min-h-screen w-full bg-background items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <p className="text-lg font-display text-muted-foreground font-medium animate-pulse">
          Loading LearnSphere...
        </p>
      </div>
    </div>
  );
}

// Protected Route Wrapper
function ProtectedRoute({ component: Component }: { component: React.ComponentType<any> }) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) return <LoadingScreen />;
  
  if (!user) {
    window.location.href = "/api/login";
    return null;
  }
  
  return (
    <Shell>
      <Component />
    </Shell>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/tutor" component={() => <ProtectedRoute component={AiTutor} />} />
      <Route path="/code-mentor" component={() => <ProtectedRoute component={CodeMentor} />} />
      
      <Route path="/roadmaps" component={() => <ProtectedRoute component={RoadmapsList} />} />
      <Route path="/roadmaps/:id" component={() => <ProtectedRoute component={ViewRoadmap} />} />
      
      <Route path="/projects" component={() => <ProtectedRoute component={ProjectsList} />} />
      <Route path="/projects/:id" component={() => <ProtectedRoute component={ViewProject} />} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
