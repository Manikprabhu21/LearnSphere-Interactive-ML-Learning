import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./app-sidebar";

export function Shell({ children }: { children: React.ReactNode }) {
  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={style}>
      <div className="flex min-h-screen w-full bg-background relative overflow-hidden text-foreground">
        
        {/* Stunning Background Ambient Effects */}
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] pointer-events-none animate-blob mix-blend-screen" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-accent/20 rounded-full blur-[120px] pointer-events-none animate-blob animation-delay-2000 mix-blend-screen" />
        <div className="absolute top-[40%] left-[40%] w-[30%] h-[30%] bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none animate-blob animation-delay-4000 mix-blend-screen" />

        <AppSidebar />
        
        <div className="flex flex-col flex-1 relative z-10 w-full max-h-screen overflow-hidden">
          <header className="flex h-16 items-center px-6 border-b border-white/5 glass-panel shrink-0 sticky top-0 z-20">
            <SidebarTrigger className="hover:bg-white/10 text-foreground" />
            <div className="ml-auto flex items-center gap-4">
              <div className="hidden md:flex items-center text-sm text-muted-foreground px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
                Press <kbd className="mx-1 px-1.5 py-0.5 rounded bg-black/40 border border-white/10 font-mono text-xs">⌘K</kbd> to search
              </div>
            </div>
          </header>
          
          <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-10 relative">
            <div className="max-w-7xl mx-auto h-full">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
