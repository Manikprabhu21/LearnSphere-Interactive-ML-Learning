import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

export function useAiTutorChat() {
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.aiTutor.chat.input>) => {
      const validated = api.aiTutor.chat.input.parse(data);
      const res = await fetch(api.aiTutor.chat.path, {
        method: api.aiTutor.chat.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error("Failed to communicate with AI Tutor");
      }
      
      const responseData = await res.json();
      return api.aiTutor.chat.responses[200].parse(responseData);
    },
  });
}
