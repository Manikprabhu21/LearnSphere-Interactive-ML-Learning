import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

export function useCodeMentorAnalyze() {
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.codeMentor.analyze.input>) => {
      const validated = api.codeMentor.analyze.input.parse(data);
      const res = await fetch(api.codeMentor.analyze.path, {
        method: api.codeMentor.analyze.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        throw new Error("Failed to analyze code");
      }
      
      const responseData = await res.json();
      return api.codeMentor.analyze.responses[200].parse(responseData);
    },
  });
}
