import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

export function useRoadmaps() {
  return useQuery({
    queryKey: [api.roadmaps.list.path],
    queryFn: async () => {
      const res = await fetch(api.roadmaps.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch roadmaps");
      const data = await res.json();
      return parseWithLogging(api.roadmaps.list.responses[200], data, "roadmaps.list");
    },
  });
}

export function useRoadmap(id: number) {
  return useQuery({
    queryKey: [api.roadmaps.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.roadmaps.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch roadmap");
      const data = await res.json();
      return parseWithLogging(api.roadmaps.get.responses[200], data, "roadmaps.get");
    },
    enabled: !!id && !isNaN(id),
  });
}

export function useCreateRoadmap() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: z.infer<typeof api.roadmaps.create.input>) => {
      const validated = api.roadmaps.create.input.parse(data);
      const res = await fetch(api.roadmaps.create.path, {
        method: api.roadmaps.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const errorData = await res.json();
          throw new Error(errorData.message || "Validation failed");
        }
        throw new Error("Failed to create roadmap");
      }
      return parseWithLogging(api.roadmaps.create.responses[201], await res.json(), "roadmaps.create");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.roadmaps.list.path] });
    },
  });
}
