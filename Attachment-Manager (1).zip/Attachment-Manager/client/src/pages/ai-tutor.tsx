import { useState, useRef, useEffect } from "react";
import { useAiTutorChat } from "@/hooks/use-ai-tutor";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bot, User, Send, Loader2, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion } from "framer-motion";

type Message = {
  role: "user" | "assistant";
  content: string;
};

export default function AiTutor() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi! I'm your AI Tutor. What would you like to learn today? I can explain complex topics, help with math, or teach you new concepts step by step." }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const chatMutation = useAiTutorChat();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || chatMutation.isPending) return;

    const userMessage = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);

    chatMutation.mutate({ prompt: userMessage }, {
      onSuccess: (data) => {
        setMessages(prev => [...prev, { role: "assistant", content: data.response }]);
      },
      onError: () => {
        setMessages(prev => [...prev, { role: "assistant", content: "**Error**: Failed to get a response. Please try again." }]);
      }
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col glass-card border border-white/10 rounded-3xl overflow-hidden bg-background/40">
      {/* Header */}
      <div className="px-6 py-4 border-b border-white/10 bg-white/5 flex items-center gap-3 shrink-0">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg">
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="font-display font-bold text-lg text-foreground flex items-center gap-2">
            AI Tutor <Sparkles className="w-4 h-4 text-primary" />
          </h2>
          <p className="text-xs text-muted-foreground">Always online and ready to help</p>
        </div>
      </div>

      {/* Chat Area */}
      <ScrollArea className="flex-1 p-4 md:p-6" viewportRef={scrollRef}>
        <div className="space-y-6 max-w-4xl mx-auto">
          {messages.map((msg, i) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={i} 
              className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <Avatar className={`w-10 h-10 border-2 ${msg.role === 'user' ? 'border-primary/50' : 'border-accent/50'}`}>
                {msg.role === 'user' ? (
                  <>
                    <AvatarFallback className="bg-primary/20"><User className="w-5 h-5 text-primary" /></AvatarFallback>
                  </>
                ) : (
                  <>
                    <AvatarFallback className="bg-accent/20"><Bot className="w-5 h-5 text-accent" /></AvatarFallback>
                  </>
                )}
              </Avatar>
              <div className={`
                max-w-[85%] rounded-2xl p-5 
                ${msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-sm shadow-lg shadow-primary/20' 
                  : 'bg-white/5 border border-white/10 text-foreground rounded-tl-sm glass-panel'}
              `}>
                {msg.role === 'user' ? (
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                ) : (
                  <div className="prose prose-invert max-w-none prose-p:leading-relaxed prose-pre:bg-black/50 prose-pre:border prose-pre:border-white/10">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          
          {chatMutation.isPending && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-4">
              <Avatar className="w-10 h-10 border-2 border-accent/50">
                <AvatarFallback className="bg-accent/20"><Bot className="w-5 h-5 text-accent" /></AvatarFallback>
              </Avatar>
              <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm p-5 flex items-center gap-2">
                <Loader2 className="w-5 h-5 text-primary animate-spin" />
                <span className="text-muted-foreground text-sm font-medium">Tutor is thinking...</span>
              </div>
            </motion.div>
          )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="p-4 bg-white/5 border-t border-white/10 shrink-0">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative flex items-end gap-2">
          <Textarea 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask a question... (Press Enter to send, Shift+Enter for new line)"
            className="min-h-[60px] max-h-[200px] resize-none rounded-2xl bg-black/40 border-white/10 focus-visible:ring-primary focus-visible:border-primary pr-14 text-base"
            rows={1}
          />
          <Button 
            type="submit" 
            size="icon"
            disabled={!input.trim() || chatMutation.isPending}
            className="absolute right-2 bottom-2 h-11 w-11 rounded-xl bg-primary hover:bg-primary/90 text-white shadow-lg disabled:opacity-50 transition-transform active:scale-95"
          >
            <Send className="w-5 h-5" />
          </Button>
        </form>
        <p className="text-center text-xs text-muted-foreground mt-3">
          AI Tutor can make mistakes. Verify important information.
        </p>
      </div>
    </div>
  );
}
