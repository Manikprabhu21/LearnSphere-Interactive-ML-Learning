import { useState } from "react";
import { useCodeMentorAnalyze } from "@/hooks/use-code-mentor";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Code2, Wand2, Terminal, Loader2, AlertCircle, Home, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion } from "framer-motion";
import { Link } from "wouter";

const LANGUAGES = [
  { value: "javascript", label: "JavaScript" },
  { value: "typescript", label: "TypeScript" },
  { value: "python", label: "Python" },
  { value: "java", label: "Java" },
  { value: "cpp", label: "C++" },
  { value: "csharp", label: "C#" },
  { value: "go", label: "Go" },
  { value: "rust", label: "Rust" },
  { value: "php", label: "PHP" },
  { value: "ruby", label: "Ruby" },
  { value: "swift", label: "Swift" },
  { value: "kotlin", label: "Kotlin" },
  { value: "golang", label: "Golang" },
  { value: "scala", label: "Scala" },
  { value: "perl", label: "Perl" },
  { value: "r", label: "R" },
  { value: "matlab", label: "MATLAB" },
  { value: "dart", label: "Dart" },
  { value: "lua", label: "Lua" },
  { value: "groovy", label: "Groovy" },
  { value: "objectivec", label: "Objective-C" },
  { value: "vb", label: "Visual Basic" },
  { value: "fortran", label: "Fortran" },
  { value: "clojure", label: "Clojure" },
  { value: "elixir", label: "Elixir" },
  { value: "erlang", label: "Erlang" },
  { value: "haskell", label: "Haskell" },
  { value: "ocaml", label: "OCaml" },
  { value: "fsharp", label: "F#" },
  { value: "assembly", label: "Assembly" },
  { value: "bash", label: "Bash" },
  { value: "shell", label: "Shell" },
  { value: "powershell", label: "PowerShell" },
  { value: "sql", label: "SQL" },
  { value: "plsql", label: "PL/SQL" },
  { value: "tsql", label: "T-SQL" },
  { value: "html", label: "HTML" },
  { value: "css", label: "CSS" },
  { value: "scss", label: "SCSS" },
  { value: "less", label: "LESS" },
  { value: "jsx", label: "JSX" },
  { value: "tsx", label: "TSX" },
  { value: "vue", label: "Vue" },
  { value: "svelte", label: "Svelte" },
  { value: "xml", label: "XML" },
  { value: "json", label: "JSON" },
  { value: "yaml", label: "YAML" },
  { value: "toml", label: "TOML" },
  { value: "markdown", label: "Markdown" },
];

export default function CodeMentor() {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const analyzeMutation = useCodeMentorAnalyze();

  const handleAnalyze = () => {
    if (!code.trim()) return;
    analyzeMutation.mutate({ code, language });
  };

  const currentLanguageLabel = LANGUAGES.find(l => l.value === language)?.label || language;

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground flex items-center gap-3">
            <Code2 className="w-10 h-10 text-emerald-400" />
            Code Mentor
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">
            Paste your code to get AI-powered reviews, bug fixes, and optimization tips.
          </p>
        </div>
        <Link href="/">
          <Button variant="outline" className="rounded-xl border-white/10 hover:bg-white/5 gap-2 transition-all hover:scale-105 active:scale-95" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <Home className="w-4 h-4" /> Back to Dashboard
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor Side */}
        <Card className="glass-card border-white/10 rounded-3xl flex flex-col h-[calc(100vh-16rem)] min-h-[500px] overflow-hidden bg-black/20">
          <div className="p-4 border-b border-white/10 bg-white/5 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Terminal className="w-4 h-4" /> Source Code
            </div>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-[180px] h-9 bg-black/40 border-white/10 rounded-xl">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-white/10 rounded-xl max-h-[300px]">
                {LANGUAGES.map(lang => (
                  <SelectItem key={lang.value} value={lang.value} className="capitalize">{lang.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <CardContent className="p-0 flex-1 relative flex flex-col">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={`// Paste your ${language} code here...`}
              className="flex-1 w-full resize-none bg-transparent border-0 focus-visible:ring-0 text-sm font-mono p-6 text-foreground placeholder:text-muted-foreground/50 rounded-none h-full"
              spellCheck={false}
            />
            <div className="p-4 border-t border-white/10 bg-black/40 shrink-0">
              <Button 
                onClick={handleAnalyze}
                disabled={!code.trim() || analyzeMutation.isPending}
                className="w-full h-12 text-base font-semibold rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white shadow-[0_0_20px_-5px_rgba(16,185,129,0.4)] transition-all hover:shadow-[0_0_30px_-5px_rgba(16,185,129,0.6)]"
              >
                {analyzeMutation.isPending ? (
                  <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Analyzing Code...</>
                ) : (
                  <><Wand2 className="w-5 h-5 mr-2" /> Review My Code</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Feedback Side */}
        <Card className="glass-card border-white/10 rounded-3xl flex flex-col h-[calc(100vh-16rem)] min-h-[500px] overflow-hidden bg-white/[0.02]">
          <div className="p-4 border-b border-white/10 bg-white/5 flex items-center gap-2 text-sm font-medium text-emerald-400 shrink-0">
            <Sparkles className="w-4 h-4" /> Mentor Feedback
          </div>
          <CardContent className="flex-1 overflow-y-auto p-6">
            {!analyzeMutation.data && !analyzeMutation.isPending && !analyzeMutation.isError && (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-50 space-y-4">
                <Code2 className="w-16 h-16 text-muted-foreground" />
                <p className="text-lg">Waiting for your code.</p>
              </div>
            )}

            {analyzeMutation.isPending && (
              <div className="h-full flex flex-col items-center justify-center space-y-6">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-emerald-500/20 rounded-full animate-spin border-t-emerald-500" />
                  <Code2 className="w-8 h-8 text-emerald-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                </div>
                <p className="text-emerald-400 animate-pulse font-medium">Scanning for bugs & improvements...</p>
              </div>
            )}

            {analyzeMutation.isError && (
              <div className="h-full flex flex-col items-center justify-center text-center text-destructive space-y-4">
                <AlertCircle className="w-16 h-16" />
                <p className="text-lg font-medium">Failed to analyze code.</p>
                <p className="text-sm opacity-80">Please try again.</p>
              </div>
            )}

            {analyzeMutation.data && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="prose prose-invert prose-emerald max-w-none prose-pre:bg-black/60 prose-pre:border prose-pre:border-white/10 prose-headings:font-display prose-headings:text-foreground prose-a:text-emerald-400"
              >
                <ReactMarkdown>{analyzeMutation.data.feedback}</ReactMarkdown>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
