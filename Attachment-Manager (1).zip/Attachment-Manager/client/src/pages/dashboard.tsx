import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare, Map as MapIcon, Briefcase, Code, Sparkles, ArrowRight, Activity, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { user } = useAuth();

  const quickActions = [
    {
      title: "Talk to AI Tutor",
      description: "Get instant help with any topic",
      icon: MessageSquare,
      color: "text-blue-400",
      bg: "bg-blue-400/10",
      link: "/tutor"
    },
    {
      title: "Generate Roadmap",
      description: "Plan your career journey step by step",
      icon: MapIcon,
      color: "text-purple-400",
      bg: "bg-purple-400/10",
      link: "/roadmaps"
    },
    {
      title: "Find a Project",
      description: "Build something to boost your skills",
      icon: Briefcase,
      color: "text-pink-400",
      bg: "bg-pink-400/10",
      link: "/projects"
    },
    {
      title: "Code Review",
      description: "Get feedback on your recent code",
      icon: Code,
      color: "text-emerald-400",
      bg: "bg-emerald-400/10",
      link: "/code-mentor"
    }
  ];

  return (
    <div className="space-y-8 pb-8">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-3xl p-8 md:p-12 glass-card border border-primary/20"
      >
        <div className="absolute top-0 right-0 p-12 opacity-20 pointer-events-none">
          <Sparkles className="w-64 h-64 text-primary animate-pulse" />
        </div>
        
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            <span>Welcome to LearnSphere AI</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground leading-tight mb-4">
            Hello, {user?.firstName || 'Student'}!<br />
            <span className="text-gradient">Ready to level up?</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8">
            Your personal AI learning ecosystem. Master new skills faster with personalized roadmaps, project ideas, and intelligent code feedback.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link href="/roadmaps">
              <Button size="lg" className="rounded-xl px-8 h-12 bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_-5px_hsl(var(--primary)_/_0.5)]">
                Start Learning Path
              </Button>
            </Link>
            <Link href="/tutor">
              <Button size="lg" variant="outline" className="rounded-xl px-8 h-12 bg-white/5 border-white/10 hover:bg-white/10 text-foreground">
                Ask AI Tutor
              </Button>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Quick Actions Grid */}
      <div>
        <h2 className="text-2xl font-display font-bold mb-6 flex items-center gap-2">
          <Activity className="w-6 h-6 text-primary" />
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, idx) => (
            <motion.div
              key={action.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
            >
              <Link href={action.link}>
                <Card className="glass-card hover-glow h-full cursor-pointer group rounded-2xl border-white/5 bg-white/[0.02]">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${action.bg} ${action.color} group-hover:scale-110 transition-transform duration-300`}>
                      <action.icon className="w-6 h-6" />
                    </div>
                    <CardTitle className="text-lg">{action.title}</CardTitle>
                    <CardDescription className="text-muted-foreground/70">{action.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Stats or Recent Activity Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-card border-white/5 rounded-3xl bg-white/[0.02]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-accent" />
              Recent Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-10 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                <MapIcon className="w-8 h-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium text-foreground">No recent activity</p>
                <p className="text-sm text-muted-foreground mt-1">Start a roadmap to track your progress here.</p>
              </div>
              <Link href="/roadmaps">
                <Button variant="link" className="text-primary hover:text-primary/80 mt-2 group">
                  Explore Roadmaps <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-white/5 rounded-3xl bg-white/[0.02]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="w-5 h-5 text-emerald-400" />
              Latest Code Reviews
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-10 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                <Code className="w-8 h-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium text-foreground">No code analyzed yet</p>
                <p className="text-sm text-muted-foreground mt-1">Paste your code to get AI feedback.</p>
              </div>
              <Link href="/code-mentor">
                <Button variant="link" className="text-emerald-400 hover:text-emerald-300 mt-2 group">
                  Try Code Mentor <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
