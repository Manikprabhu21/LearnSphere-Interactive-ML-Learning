import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useProjects, useCreateProject } from "@/hooks/use-projects";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Briefcase, Plus, ChevronRight, Loader2, LayoutTemplate } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function ProjectsList() {
  const { data: projects, isLoading } = useProjects();
  const createMutation = useCreateProject();
  const [domain, setDomain] = useState("");
  const [skillLevel, setSkillLevel] = useState("beginner");
  const [open, setOpen] = useState(false);
  const [, setLocation] = useLocation();

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain.trim()) return;
    
    createMutation.mutate({ domain, skillLevel }, {
      onSuccess: (data) => {
        setOpen(false);
        setDomain("");
        setLocation(`/projects/${data.id}`);
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground flex items-center gap-3">
            <Briefcase className="w-10 h-10 text-pink-400" />
            Project Generator
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">
            Build a portfolio with AI-tailored project ideas and architectures.
          </p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-pink-500 hover:bg-pink-600 text-white h-12 px-6 shadow-[0_0_20px_-5px_rgba(236,72,153,0.5)]">
              <Plus className="w-5 h-5 mr-2" /> Generate Project
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-panel border-white/10 rounded-3xl sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-display text-foreground">New Project Idea</DialogTitle>
              <DialogDescription className="text-base text-muted-foreground">
                Define your interest and skill level to get a custom project spec.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-6 mt-4">
              <div className="space-y-3">
                <Label htmlFor="domain" className="text-foreground">Domain / Tech Stack</Label>
                <Input
                  id="domain"
                  placeholder="e.g., React & Node.js, Machine Learning, Web3..."
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="h-12 bg-black/40 border-white/10 rounded-xl focus-visible:ring-pink-500"
                />
              </div>
              <div className="space-y-3">
                <Label htmlFor="skillLevel" className="text-foreground">Skill Level</Label>
                <Select value={skillLevel} onValueChange={setSkillLevel}>
                  <SelectTrigger className="h-12 bg-black/40 border-white/10 rounded-xl">
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-white/10 rounded-xl">
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                type="submit" 
                className="w-full h-12 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-base font-semibold"
                disabled={!domain.trim() || createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating Idea...</>
                ) : (
                  "Generate Project Spec"
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <Card key={i} className="h-48 glass-card border-white/5 animate-pulse bg-white/5" />
          ))}
        </div>
      ) : projects?.length === 0 ? (
        <Card className="glass-card border-white/5 bg-white/[0.02] py-20 text-center rounded-3xl">
          <CardContent className="flex flex-col items-center justify-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-pink-500/10 flex items-center justify-center">
              <LayoutTemplate className="w-10 h-10 text-pink-400" />
            </div>
            <h3 className="text-2xl font-display font-semibold text-foreground">No projects yet</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              Generate a unique project idea to practice your skills and build your portfolio.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects?.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Link href={`/projects/${project.id}`}>
                <Card className="glass-card hover-glow cursor-pointer h-full border-white/5 rounded-3xl group bg-white/[0.02] flex flex-col">
                  <CardHeader>
                    <div className="flex justify-between items-start mb-4">
                      <div className="w-12 h-12 rounded-xl bg-pink-500/20 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                        <Briefcase className="w-6 h-6" />
                      </div>
                      <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-muted-foreground capitalize">
                        {project.skillLevel}
                      </span>
                    </div>
                    <CardTitle className="text-xl line-clamp-1 text-foreground">
                      {project.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2 mt-2">
                      {project.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-center text-pink-400 font-medium text-sm mt-auto pt-4">
                    View Specifications <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
