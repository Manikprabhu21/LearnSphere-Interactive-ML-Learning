import { useRoute, Link } from "wouter";
import { useProject } from "@/hooks/use-projects";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Briefcase, Loader2, Sparkles, Code2, Layers } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion } from "framer-motion";

export default function ViewProject() {
  const [, params] = useRoute("/projects/:id");
  const { data: project, isLoading, isError } = useProject(Number(params?.id));

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="w-10 h-10 text-pink-500 animate-spin" />
      </div>
    );
  }

  if (isError || !project) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-destructive">Project not found</h2>
        <Link href="/projects">
          <Button variant="link" className="mt-4 text-primary">Return to Projects</Button>
        </Link>
      </div>
    );
  }

  const content = typeof project.content === 'string' ? project.content : JSON.stringify(project.content, null, 2);

  return (
    <motion.div 
      className="max-w-4xl mx-auto space-y-8 pb-12"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Link href="/projects">
        <Button variant="ghost" className="text-muted-foreground hover:text-foreground mb-4 gap-2 group transition-all hover:scale-105 active:scale-95" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Projects
        </Button>
      </Link>

      <div className="p-8 md:p-12 rounded-3xl bg-gradient-to-br from-pink-500/20 via-primary/10 to-background border border-pink-500/20 glass-card relative overflow-hidden">
        <Briefcase className="absolute -right-10 -bottom-10 w-64 h-64 text-pink-500/10 pointer-events-none" />
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-muted-foreground text-sm font-medium mb-6 relative z-10 capitalize">
          <Layers className="w-4 h-4" /> {project.skillLevel} • {project.domain}
        </div>
        <h1 className="text-3xl md:text-5xl font-display font-bold text-foreground mb-4 relative z-10 leading-tight">
          {project.title}
        </h1>
        <p className="text-lg text-muted-foreground relative z-10 max-w-2xl">
          {project.description}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 overflow-hidden">
        <div className="md:col-span-2 space-y-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <Card className="glass-card border-white/10 rounded-3xl bg-white/[0.02]">
              <div className="p-6 border-b border-white/10 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-pink-400" />
                <h2 className="text-xl font-display font-semibold">Project Specifications</h2>
              </div>
              <CardContent className="p-6 max-h-[600px] overflow-y-auto">
                <div className="prose prose-invert prose-pink max-w-none prose-p:leading-relaxed prose-pre:bg-black/60 prose-pre:border-white/10 prose-pre:max-w-full prose-pre:overflow-x-auto">
                  <ReactMarkdown>{content}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
        
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="glass-card border-white/10 rounded-3xl bg-primary/5">
              <CardContent className="p-6 text-center">
                <Code2 className="w-12 h-12 mx-auto text-primary mb-4" />
                <h3 className="font-semibold text-lg mb-2">Ready to code?</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  Start building this project. Once you have some code, use our Code Mentor to review it!
                </p>
                <Link href="/code-mentor">
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button className="w-full rounded-xl bg-primary hover:bg-primary/90">
                      Open Code Mentor
                    </Button>
                  </motion.div>
                </Link>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
