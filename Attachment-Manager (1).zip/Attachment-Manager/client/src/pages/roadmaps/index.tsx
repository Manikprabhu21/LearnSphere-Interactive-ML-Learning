import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useRoadmaps, useCreateRoadmap } from "@/hooks/use-roadmaps";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Map, Plus, ChevronRight, Loader2, Target } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function RoadmapsList() {
  const { data: roadmaps, isLoading } = useRoadmaps();
  const createMutation = useCreateRoadmap();
  const [goal, setGoal] = useState("");
  const [open, setOpen] = useState(false);
  const [, setLocation] = useLocation();

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goal.trim()) return;
    
    createMutation.mutate({ careerGoal: goal }, {
      onSuccess: (data) => {
        setOpen(false);
        setGoal("");
        setLocation(`/roadmaps/${data.id}`);
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground flex items-center gap-3">
            <Map className="w-10 h-10 text-purple-400" />
            Learning Roadmaps
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">
            AI-generated, step-by-step paths to reach your career goals.
          </p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-xl bg-purple-500 hover:bg-purple-600 text-white h-12 px-6 shadow-[0_0_20px_-5px_rgba(168,85,247,0.5)]">
              <Plus className="w-5 h-5 mr-2" /> Create Roadmap
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-panel border-white/10 rounded-3xl sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-display text-foreground">New Learning Path</DialogTitle>
              <DialogDescription className="text-base text-muted-foreground">
                What do you want to become? Be specific for a better roadmap.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-6 mt-4">
              <div className="space-y-3">
                <Label htmlFor="goal" className="text-foreground">Career Goal</Label>
                <Input
                  id="goal"
                  placeholder="e.g., Fullstack React Developer, Data Scientist..."
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  className="h-12 bg-black/40 border-white/10 rounded-xl focus-visible:ring-purple-500"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full h-12 rounded-xl bg-purple-500 hover:bg-purple-600 text-white text-base font-semibold"
                disabled={!goal.trim() || createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating AI Path...</>
                ) : (
                  "Generate Roadmap"
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <Card key={i} className="h-48 glass-card border-white/5 animate-pulse bg-white/5" />
          ))}
        </div>
      ) : roadmaps?.length === 0 ? (
        <Card className="glass-card border-white/5 bg-white/[0.02] py-20 text-center rounded-3xl">
          <CardContent className="flex flex-col items-center justify-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-purple-500/10 flex items-center justify-center">
              <Target className="w-10 h-10 text-purple-400" />
            </div>
            <h3 className="text-2xl font-display font-semibold text-foreground">No roadmaps yet</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              Create your first learning roadmap to get a customized, step-by-step guide to achieving your dream career.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {roadmaps?.map((roadmap, idx) => (
            <motion.div
              key={roadmap.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Link href={`/roadmaps/${roadmap.id}`}>
                <Card className="glass-card hover-glow cursor-pointer h-full border-white/5 rounded-3xl group bg-white/[0.02]">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mb-4 text-purple-400 group-hover:scale-110 transition-transform">
                      <Target className="w-6 h-6" />
                    </div>
                    <CardTitle className="text-xl line-clamp-2 text-foreground leading-tight">
                      {roadmap.careerGoal}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-2">
                      Created {format(new Date(roadmap.createdAt!), "MMM d, yyyy")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-center text-purple-400 font-medium text-sm mt-auto">
                    View Path <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
