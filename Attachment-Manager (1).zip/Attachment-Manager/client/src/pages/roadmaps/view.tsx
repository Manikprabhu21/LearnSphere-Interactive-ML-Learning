import { useRoute, Link } from "wouter";
import { useRoadmap } from "@/hooks/use-roadmaps";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Map, CheckCircle2, Loader2, ChevronRight } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion } from "framer-motion";

export default function ViewRoadmap() {
  const [, params] = useRoute("/roadmaps/:id");
  const { data: roadmap, isLoading, isError } = useRoadmap(Number(params?.id));

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="w-10 h-10 text-purple-500 animate-spin" />
      </div>
    );
  }

  if (isError || !roadmap) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-destructive">Roadmap not found</h2>
        <Link href="/roadmaps">
          <Button variant="link" className="mt-4 text-primary">Return to Roadmaps</Button>
        </Link>
      </div>
    );
  }

  // Safely parse JSON content from DB
  let steps = [];
  try {
    steps = typeof roadmap.content === 'string' ? JSON.parse(roadmap.content) : roadmap.content;
    if (!Array.isArray(steps)) steps = [{ title: "Roadmap details", description: JSON.stringify(roadmap.content) }];
  } catch (e) {
    steps = [{ title: "Raw Roadmap", description: String(roadmap.content) }];
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <Link href="/roadmaps">
        <Button variant="ghost" className="text-muted-foreground hover:text-foreground mb-4 transition-all hover:scale-105 active:scale-95" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Roadmaps
        </Button>
      </Link>

      <div className="p-8 md:p-12 rounded-3xl bg-gradient-to-br from-purple-500/20 via-primary/10 to-background border border-purple-500/20 glass-card relative overflow-hidden">
        <Map className="absolute -right-10 -bottom-10 w-64 h-64 text-purple-500/10 pointer-events-none" />
        <h1 className="text-3xl md:text-5xl font-display font-bold text-foreground mb-4 relative z-10">
          {roadmap.careerGoal}
        </h1>
        <p className="text-lg text-muted-foreground relative z-10">
          Your personalized step-by-step path to mastery. Follow these steps in order.
        </p>
      </div>

      <div className="relative border-l-2 border-white/10 ml-4 md:ml-8 space-y-12">
        {steps.map((step: any, idx: number) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.15 }}
            className="relative pl-8 md:pl-12"
          >
            <div className="absolute -left-[13px] top-1 w-6 h-6 rounded-full bg-background border-2 border-purple-500 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              <div className="w-2 h-2 rounded-full bg-purple-400" />
            </div>
            
            <Card className="glass-card border-white/10 rounded-2xl bg-white/[0.02] hover:border-purple-500/30 transition-colors">
              <CardContent className="p-6">
                <h3 className="text-2xl font-display font-semibold text-foreground mb-3 flex items-center gap-2">
                  <span className="text-purple-400 text-lg">Step {idx + 1}:</span> {step.title || step.name || "Phase"}
                </h3>
                <div className="prose prose-invert max-w-none text-muted-foreground prose-p:leading-relaxed">
                  <ReactMarkdown>{step.description || step.content || String(step)}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
