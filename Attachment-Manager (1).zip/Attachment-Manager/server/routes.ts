import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerAuthRoutes } from "./replit_integrations/auth";
import { isAuthenticated } from "./replit_integrations/auth/replitAuth";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register Auth Routes
  registerAuthRoutes(app);

  // --- Roadmaps ---
  app.get(api.roadmaps.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const roadmaps = await storage.getRoadmapsByUserId(req.user.claims.sub);
      res.json(roadmaps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch roadmaps" });
    }
  });

  app.get(api.roadmaps.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const roadmap = await storage.getRoadmap(Number(req.params.id));
      if (!roadmap) {
        return res.status(404).json({ message: "Roadmap not found" });
      }
      if (roadmap.userId !== req.user.claims.sub) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      res.json(roadmap);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch roadmap" });
    }
  });

  app.post(api.roadmaps.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.roadmaps.create.input.parse(req.body);
      
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{
          role: "user",
          content: `Create a step-by-step learning roadmap for a student aiming to become a ${input.careerGoal}. Provide output in JSON format containing an array of steps. Each step should have a 'title' and 'description'.`
        }],
        response_format: { type: "json_object" }
      });

      let content = [];
      if (response.choices[0]?.message?.content) {
        const parsed = JSON.parse(response.choices[0].message.content);
        content = Array.isArray(parsed) ? parsed : (parsed.steps || []);
      }

      const roadmap = await storage.createRoadmap(req.user.claims.sub, input.careerGoal, content);
      res.status(201).json(roadmap);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to create roadmap" });
    }
  });

  // --- Projects ---
  app.get(api.projects.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const projects = await storage.getProjectsByUserId(req.user.claims.sub);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get(api.projects.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const project = await storage.getProject(Number(req.params.id));
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      if (project.userId !== req.user.claims.sub) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post(api.projects.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{
          role: "user",
          content: `Generate a project idea for a student with skill level '${input.skillLevel}' in the domain of '${input.domain}'. Provide output in JSON format with 'title', 'description', and 'content' (which contains architecture, dataset suggestions, etc.).`
        }],
        response_format: { type: "json_object" }
      });

      let parsed = { title: "New Project", description: "Generated project", content: {} };
      if (response.choices[0]?.message?.content) {
        parsed = JSON.parse(response.choices[0].message.content);
      }

      const project = await storage.createProject(
        req.user.claims.sub,
        parsed.title || `Project in ${input.domain}`,
        parsed.description || "Project description",
        input.domain,
        input.skillLevel,
        parsed.content || parsed
      );
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // --- AI Tutor ---
  app.post(api.aiTutor.chat.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.aiTutor.chat.input.parse(req.body);
      
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are an AI Personal Tutor for a student. Explain concepts simply and provide examples." },
          { role: "user", content: input.prompt }
        ]
      });

      res.status(200).json({ response: response.choices[0]?.message?.content || "" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to process chat" });
    }
  });

  // --- Code Mentor ---
  app.post(api.codeMentor.analyze.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.codeMentor.analyze.input.parse(req.body);
      
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          { role: "system", content: "You are a Code Mentor. Analyze the user's code, detect errors, explain bugs, and suggest optimized solutions." },
          { role: "user", content: `Language: ${input.language}\nCode:\n${input.code}` }
        ]
      });

      res.status(200).json({ feedback: response.choices[0]?.message?.content || "" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: error.errors[0].message,
          field: error.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  return httpServer;
}
