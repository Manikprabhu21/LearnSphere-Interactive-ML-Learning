import { db } from "./db";
import { 
  roadmaps, projects, studyPlans, resumes, users,
  type Roadmap, type Project, type StudyPlan, type Resume
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Roadmaps
  getRoadmap(id: number): Promise<Roadmap | undefined>;
  getRoadmapsByUserId(userId: string): Promise<Roadmap[]>;
  createRoadmap(userId: string, careerGoal: string, content: any): Promise<Roadmap>;

  // Projects
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: string): Promise<Project[]>;
  createProject(userId: string, title: string, description: string, domain: string, skillLevel: string, content: any): Promise<Project>;
}

export class DatabaseStorage implements IStorage {
  async getRoadmap(id: number): Promise<Roadmap | undefined> {
    const [roadmap] = await db.select().from(roadmaps).where(eq(roadmaps.id, id));
    return roadmap;
  }
  async getRoadmapsByUserId(userId: string): Promise<Roadmap[]> {
    return await db.select().from(roadmaps).where(eq(roadmaps.userId, userId));
  }
  async createRoadmap(userId: string, careerGoal: string, content: any): Promise<Roadmap> {
    const [roadmap] = await db.insert(roadmaps).values({
      userId, careerGoal, content
    }).returning();
    return roadmap;
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }
  async getProjectsByUserId(userId: string): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId));
  }
  async createProject(userId: string, title: string, description: string, domain: string, skillLevel: string, content: any): Promise<Project> {
    const [project] = await db.insert(projects).values({
      userId, title, description, domain, skillLevel, content
    }).returning();
    return project;
  }
}

export const storage = new DatabaseStorage();
