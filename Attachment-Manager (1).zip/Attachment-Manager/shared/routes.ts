import { z } from 'zod';
import { insertRoadmapSchema, roadmaps, insertProjectSchema, projects, insertStudyPlanSchema, studyPlans, insertResumeSchema, resumes } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  roadmaps: {
    list: {
      method: 'GET' as const,
      path: '/api/roadmaps' as const,
      responses: {
        200: z.array(z.custom<typeof roadmaps.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/roadmaps' as const,
      input: z.object({ careerGoal: z.string().min(1) }),
      responses: {
        201: z.custom<typeof roadmaps.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/roadmaps/:id' as const,
      responses: {
        200: z.custom<typeof roadmaps.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  projects: {
    list: {
      method: 'GET' as const,
      path: '/api/projects' as const,
      responses: {
        200: z.array(z.custom<typeof projects.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/projects' as const,
      input: z.object({ skillLevel: z.string(), domain: z.string() }),
      responses: {
        201: z.custom<typeof projects.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/projects/:id' as const,
      responses: {
        200: z.custom<typeof projects.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },
  aiTutor: {
    chat: {
      method: 'POST' as const,
      path: '/api/ai-tutor' as const,
      input: z.object({ prompt: z.string().min(1) }),
      responses: {
        200: z.object({ response: z.string() }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
  codeMentor: {
    analyze: {
      method: 'POST' as const,
      path: '/api/code-mentor' as const,
      input: z.object({ code: z.string().min(1), language: z.string() }),
      responses: {
        200: z.object({ feedback: z.string() }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
