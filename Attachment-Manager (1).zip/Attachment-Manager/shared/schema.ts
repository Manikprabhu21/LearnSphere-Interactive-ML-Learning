import { pgTable, text, serial, jsonb, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users, sessions } from "./models/auth";

export { users, sessions };

export const roadmaps = pgTable("roadmaps", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  careerGoal: text("career_goal").notNull(),
  content: jsonb("content").notNull(), // Array of steps/timeline
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  domain: text("domain").notNull(),
  skillLevel: text("skill_level").notNull(),
  content: jsonb("content").notNull(), // Architecture, ideas, dataset suggestions
  createdAt: timestamp("created_at").defaultNow(),
});

export const studyPlans = pgTable("study_plans", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  content: jsonb("content").notNull(), // Weekly plans
  createdAt: timestamp("created_at").defaultNow(),
});

export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  content: text("content").notNull(), // Raw resume text or user inputted skills
  analysis: jsonb("analysis"), // AI feedback (skills extracted, missing skills, improvements)
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRoadmapSchema = createInsertSchema(roadmaps).omit({ id: true, createdAt: true });
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertStudyPlanSchema = createInsertSchema(studyPlans).omit({ id: true, createdAt: true });
export const insertResumeSchema = createInsertSchema(resumes).omit({ id: true, createdAt: true });

export type Roadmap = typeof roadmaps.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type StudyPlan = typeof studyPlans.$inferSelect;
export type Resume = typeof resumes.$inferSelect;
